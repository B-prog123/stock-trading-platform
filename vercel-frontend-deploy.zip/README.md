# Stockify AI Deployment Guide

Architecture:
- Frontend: React + Vite (deploy to Vercel)
- Backend: Node.js + Express API (deploy to Render or Railway)
- Database: MongoDB Atlas

## Local Development

1. Install dependencies:
`npm install`

2. Create `.env` from `.env.example` and set values.

3. Run frontend:
`npm run dev`

4. Run backend (separate terminal):
`npm run dev:backend`

Frontend runs on Vite default port (`5173`).
Backend runs on `PORT` (default `4000`).

## Frontend Deploy (Vercel)

1. Import this repo in Vercel.
2. Framework preset: `Vite`.
3. Build command: `npm run build`
4. Output directory: `dist`
5. Set env var in Vercel:
   - `VITE_API_BASE_URL=https://<your-backend-domain>`

## Backend Deploy (Render / Railway)

Start command:
`npm run dev:backend` (for dev environments) or `npm start` (recommended prod)

Set backend env vars:
- `MONGODB_URI`
- `JWT_SECRET`
- `FRONTEND_URL`
- `GEMINI_API_KEY`
- `PORT`

## MongoDB Atlas

1. Create cluster.
2. Create database user.
3. Allow network access from backend host.
4. Copy connection string to `MONGODB_URI`.

## Notes

- API health check: `/api/health`
- SIP scheduler runs every 60 seconds on backend.
- Frontend API calls now use `VITE_API_BASE_URL` via `src/lib/api.ts`.

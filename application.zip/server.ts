import express from "express";
import axios from "axios";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "stockify-secret-key";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const gemini = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;

const limitedChatSolutions: { prompt: string; answer: string; keywords: string[] }[] = [
  {
    prompt: "How do I start trading safely?",
    keywords: ["start trading", "beginner", "new to trading", "first trade"],
    answer: "Use small position sizes (1-2% risk per trade), set stop-loss before entry, and avoid leverage until you have a tested strategy."
  },
  {
    prompt: "How should I manage risk?",
    keywords: ["risk", "stop loss", "drawdown", "loss"],
    answer: "Define max loss per trade, set a daily loss cap, and reduce size after 2-3 losing trades to protect capital."
  },
  {
    prompt: "How to diversify my portfolio?",
    keywords: ["diversify", "portfolio", "allocation", "concentration"],
    answer: "Spread exposure across sectors, avoid oversized single positions, and rebalance monthly to keep risk balanced."
  },
  {
    prompt: "When should I buy or sell?",
    keywords: ["buy", "sell", "entry", "exit"],
    answer: "Buy only when your setup confirms trend and risk-reward is at least 1:2. Sell when stop-loss is hit or your target thesis is completed."
  },
  {
    prompt: "How do I read market trend?",
    keywords: ["trend", "market", "momentum", "news"],
    answer: "Check higher timeframe direction first, confirm with volume, then align entries with trend instead of predicting reversals."
  }
];

const getLimitedChatReply = (rawMessage: string): string => {
  const message = rawMessage.toLowerCase();
  const match = limitedChatSolutions.find((item) =>
    item.keywords.some((keyword) => message.includes(keyword))
  );

  if (match) {
    return match.answer;
  }

  const supported = limitedChatSolutions
    .map((item, idx) => `${idx + 1}. ${item.prompt}`)
    .join("\n");

  return `I support only limited questions right now. Ask one of these:\n${supported}`;
};

const toISODate = (date: Date): string => date.toISOString().split("T")[0];

const parseISODate = (value: string): Date | null => {
  if (!value) return null;
  const parsed = new Date(`${value}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) return null;
  parsed.setHours(0, 0, 0, 0);
  return parsed;
};

const addDays = (date: Date, days: number): Date => {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  next.setHours(0, 0, 0, 0);
  return next;
};

const addMonths = (date: Date, months: number): Date => {
  const next = new Date(date);
  next.setMonth(next.getMonth() + months);
  next.setHours(0, 0, 0, 0);
  return next;
};

const getNextSipDate = (fromDate: Date, frequency: "WEEKLY" | "MONTHLY"): Date => {
  return frequency === "WEEKLY" ? addDays(fromDate, 7) : addMonths(fromDate, 1);
};

const fallbackPrices: Record<string, number> = {
  AAPL: 182.63,
  TSLA: 202.64,
  NVDA: 726.13,
  MSFT: 409.72,
  GOOGL: 147.22,
  AMZN: 174.42,
};

const getCurrentStockPrice = async (symbol: string): Promise<number> => {
  const safeSymbol = symbol.trim().toUpperCase();
  try {
    const response = await axios.get("https://query1.finance.yahoo.com/v7/finance/quote", {
      params: { symbols: safeSymbol },
      timeout: 4000,
    });

    const price = response?.data?.quoteResponse?.result?.[0]?.regularMarketPrice;
    if (typeof price === "number" && price > 0) {
      return price;
    }
  } catch (error) {
    console.error(`Price API fallback for ${safeSymbol}:`, error);
  }

  return fallbackPrices[safeSymbol] || 100;
};

const db = new Database("stockify.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    balance REAL DEFAULT 10000.0
  );

  CREATE TABLE IF NOT EXISTS portfolio (
    userId INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    quantity REAL NOT NULL,
    avgPrice REAL NOT NULL,
    PRIMARY KEY (userId, symbol),
    FOREIGN KEY (userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS watchlist (
    userId INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    PRIMARY KEY (userId, symbol),
    FOREIGN KEY (userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    targetPrice REAL NOT NULL,
    type TEXT CHECK(type IN ('ABOVE', 'BELOW')) NOT NULL,
    active INTEGER DEFAULT 1,
    FOREIGN KEY (userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    quantity REAL NOT NULL,
    price REAL NOT NULL,
    type TEXT CHECK(type IN ('BUY', 'SELL')) NOT NULL,
    source TEXT CHECK(source IN ('MANUAL', 'SIP')) DEFAULT 'MANUAL',
    sipOrderId INTEGER,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS sip_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER NOT NULL,
    stockSymbol TEXT NOT NULL,
    investmentAmount REAL NOT NULL,
    frequency TEXT CHECK(frequency IN ('WEEKLY', 'MONTHLY')) NOT NULL,
    startDate TEXT NOT NULL,
    endDate TEXT,
    totalInvested REAL DEFAULT 0,
    totalShares REAL DEFAULT 0,
    status TEXT CHECK(status IN ('ACTIVE', 'PAUSED', 'CANCELLED', 'COMPLETED')) DEFAULT 'ACTIVE',
    nextRunDate TEXT NOT NULL,
    lastExecutedAt TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS sip_executions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sipId INTEGER NOT NULL,
    userId INTEGER NOT NULL,
    stockSymbol TEXT NOT NULL,
    scheduledDate TEXT NOT NULL,
    executedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    price REAL,
    amount REAL,
    shares REAL,
    status TEXT CHECK(status IN ('SUCCESS', 'FAILED')) NOT NULL,
    error TEXT,
    FOREIGN KEY (sipId) REFERENCES sip_orders(id),
    FOREIGN KEY (userId) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS sip_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER NOT NULL,
    sipId INTEGER,
    type TEXT CHECK(type IN ('EXECUTED', 'COMPLETED', 'FAILED')) NOT NULL,
    message TEXT NOT NULL,
    read INTEGER DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sipId) REFERENCES sip_orders(id),
    FOREIGN KEY (userId) REFERENCES users(id)
  );
`);

const transactionsCols = db.prepare("PRAGMA table_info(transactions)").all() as Array<{ name: string }>;
if (!transactionsCols.some((col) => col.name === "source")) {
  db.prepare("ALTER TABLE transactions ADD COLUMN source TEXT DEFAULT 'MANUAL'").run();
}
if (!transactionsCols.some((col) => col.name === "sipOrderId")) {
  db.prepare("ALTER TABLE transactions ADD COLUMN sipOrderId INTEGER").run();
}

app.use(express.json());

const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

const createSipNotification = (userId: number, sipId: number, type: "EXECUTED" | "COMPLETED" | "FAILED", message: string) => {
  db.prepare("INSERT INTO sip_notifications (userId, sipId, type, message) VALUES (?, ?, ?, ?)").run(userId, sipId, type, message);
};

const executeDueSip = async (sip: any) => {
  const scheduledDate = parseISODate(sip.nextRunDate);
  if (!scheduledDate) return;

  const endDate = sip.endDate ? parseISODate(sip.endDate) : null;
  if (endDate && scheduledDate > endDate) {
    db.prepare("UPDATE sip_orders SET status = 'COMPLETED', nextRunDate = NULL WHERE id = ?").run(sip.id);
    createSipNotification(sip.userId, sip.id, "COMPLETED", `SIP for ${sip.stockSymbol} is completed.`);
    return;
  }

  let stockPrice = 0;
  try {
    stockPrice = await getCurrentStockPrice(sip.stockSymbol);
  } catch {
    stockPrice = 0;
  }

  if (!stockPrice || stockPrice <= 0) {
    const nextAfterFailure = getNextSipDate(scheduledDate, sip.frequency);
    db.prepare("UPDATE sip_orders SET nextRunDate = ? WHERE id = ?").run(toISODate(nextAfterFailure), sip.id);
    db.prepare("INSERT INTO sip_executions (sipId, userId, stockSymbol, scheduledDate, status, error) VALUES (?, ?, ?, ?, 'FAILED', ?)")
      .run(sip.id, sip.userId, sip.stockSymbol, sip.nextRunDate, "Unable to fetch stock price");
    createSipNotification(sip.userId, sip.id, "FAILED", `SIP for ${sip.stockSymbol} failed: stock price unavailable.`);
    return;
  }

  const user: any = db.prepare("SELECT balance FROM users WHERE id = ?").get(sip.userId);
  if (!user || user.balance < sip.investmentAmount) {
    const nextAfterFailure = getNextSipDate(scheduledDate, sip.frequency);
    db.prepare("UPDATE sip_orders SET nextRunDate = ? WHERE id = ?").run(toISODate(nextAfterFailure), sip.id);
    db.prepare("INSERT INTO sip_executions (sipId, userId, stockSymbol, scheduledDate, price, amount, status, error) VALUES (?, ?, ?, ?, ?, ?, 'FAILED', ?)")
      .run(sip.id, sip.userId, sip.stockSymbol, sip.nextRunDate, stockPrice, sip.investmentAmount, "Insufficient wallet balance");
    createSipNotification(sip.userId, sip.id, "FAILED", `SIP for ${sip.stockSymbol} failed due to insufficient balance.`);
    return;
  }

  const shares = parseFloat((sip.investmentAmount / stockPrice).toFixed(6));
  const nextRun = getNextSipDate(scheduledDate, sip.frequency);
  const shouldComplete = endDate && nextRun > endDate;

  const tx = db.transaction(() => {
    db.prepare("UPDATE users SET balance = balance - ? WHERE id = ?").run(sip.investmentAmount, sip.userId);

    const existing: any = db.prepare("SELECT * FROM portfolio WHERE userId = ? AND symbol = ?").get(sip.userId, sip.stockSymbol);
    if (existing) {
      const newQty = existing.quantity + shares;
      const newAvg = ((existing.avgPrice * existing.quantity) + (stockPrice * shares)) / newQty;
      db.prepare("UPDATE portfolio SET quantity = ?, avgPrice = ? WHERE userId = ? AND symbol = ?")
        .run(newQty, newAvg, sip.userId, sip.stockSymbol);
    } else {
      db.prepare("INSERT INTO portfolio (userId, symbol, quantity, avgPrice) VALUES (?, ?, ?, ?)")
        .run(sip.userId, sip.stockSymbol, shares, stockPrice);
    }

    db.prepare("INSERT INTO transactions (userId, symbol, quantity, price, type, source, sipOrderId) VALUES (?, ?, ?, ?, 'BUY', 'SIP', ?)")
      .run(sip.userId, sip.stockSymbol, shares, stockPrice, sip.id);

    db.prepare("INSERT INTO sip_executions (sipId, userId, stockSymbol, scheduledDate, price, amount, shares, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'SUCCESS')")
      .run(sip.id, sip.userId, sip.stockSymbol, sip.nextRunDate, stockPrice, sip.investmentAmount, shares);

    db.prepare("UPDATE sip_orders SET totalInvested = totalInvested + ?, totalShares = totalShares + ?, lastExecutedAt = ?, nextRunDate = ?, status = ? WHERE id = ?")
      .run(
        sip.investmentAmount,
        shares,
        toISODate(scheduledDate),
        shouldComplete ? null : toISODate(nextRun),
        shouldComplete ? "COMPLETED" : "ACTIVE",
        sip.id
      );
  });

  tx();
  createSipNotification(sip.userId, sip.id, "EXECUTED", `SIP executed for ${sip.stockSymbol}: $${sip.investmentAmount.toFixed(2)} invested.`);
  if (shouldComplete) {
    createSipNotification(sip.userId, sip.id, "COMPLETED", `SIP for ${sip.stockSymbol} has reached its end date and is now completed.`);
  }
};

const processDueSips = async () => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayIso = toISODate(today);

    const dueSips = db.prepare("SELECT * FROM sip_orders WHERE status = 'ACTIVE' AND nextRunDate IS NOT NULL AND nextRunDate <= ? ORDER BY nextRunDate ASC").all(todayIso);
    for (const sip of dueSips) {
      await executeDueSip(sip);
    }
  } catch (error) {
    console.error("SIP scheduler error:", error);
  }
};

app.post("/api/auth/register", async (req, res) => {
  const { email, password, name } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const stmt = db.prepare("INSERT INTO users (email, password, name) VALUES (?, ?, ?)");
    const info = stmt.run(email, hashedPassword, name);
    res.status(201).json({ id: info.lastInsertRowid });
  } catch {
    res.status(400).json({ error: "Email already exists" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user: any = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ error: "Invalid credentials" });
  }

  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
  res.json({ token, user: { id: user.id, email: user.email, name: user.name, balance: user.balance } });
});

app.get("/api/user/profile", authenticateToken, (req: any, res) => {
  try {
    const user: any = db.prepare("SELECT id, email, name, balance FROM users WHERE id = ?").get(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (error) {
    console.error("Profile fetch error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.put("/api/user/profile", authenticateToken, (req: any, res) => {
  const { name } = req.body;
  if (typeof name !== "string" || !name.trim()) {
    return res.status(400).json({ error: "Invalid name" });
  }

  try {
    db.prepare("UPDATE users SET name = ? WHERE id = ?").run(name.trim(), req.user.id);
    const user: any = db.prepare("SELECT id, email, name, balance FROM users WHERE id = ?").get(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (error) {
    console.error("Profile update error:", error);
    res.status(500).json({ error: "Failed to update profile" });
  }
});

app.post("/api/user/wallet/deposit", authenticateToken, (req: any, res) => {
  const { amount } = req.body;
  if (typeof amount !== "number" || amount <= 0) {
    return res.status(400).json({ error: "Invalid deposit amount" });
  }

  try {
    db.prepare("UPDATE users SET balance = balance + ? WHERE id = ?").run(amount, req.user.id);
    const user: any = db.prepare("SELECT balance FROM users WHERE id = ?").get(req.user.id);
    res.json({ balance: user.balance });
  } catch (error) {
    console.error("Deposit error:", error);
    res.status(500).json({ error: "Deposit failed" });
  }
});

app.get("/api/portfolio", authenticateToken, (req: any, res) => {
  try {
    const portfolio = db.prepare("SELECT * FROM portfolio WHERE userId = ?").all(req.user.id);
    res.json(portfolio || []);
  } catch (error) {
    console.error("Portfolio fetch error:", error);
    res.status(500).json({ error: "Failed to fetch portfolio" });
  }
});

app.get("/api/portfolio/performance", authenticateToken, async (req: any, res) => {
  try {
    const portfolio: any[] = db.prepare("SELECT * FROM portfolio WHERE userId = ?").all(req.user.id) as any[];

    const items = await Promise.all(
      portfolio.map(async (item) => {
        const currentPrice = await getCurrentStockPrice(item.symbol);
        const investedValue = item.quantity * item.avgPrice;
        const currentValue = item.quantity * currentPrice;
        const profitLoss = currentValue - investedValue;
        const profitLossPercent = investedValue > 0 ? (profitLoss / investedValue) * 100 : 0;

        return {
          symbol: item.symbol,
          quantity: item.quantity,
          avgPrice: item.avgPrice,
          currentPrice,
          investedValue,
          currentValue,
          profitLoss,
          profitLossPercent,
        };
      })
    );

    const totals = items.reduce(
      (acc, item) => {
        acc.investedValue += item.investedValue;
        acc.currentValue += item.currentValue;
        acc.profitLoss += item.profitLoss;
        return acc;
      },
      { investedValue: 0, currentValue: 0, profitLoss: 0 }
    );

    const totalProfitLossPercent = totals.investedValue > 0 ? (totals.profitLoss / totals.investedValue) * 100 : 0;

    res.json({
      items,
      totals: {
        ...totals,
        profitLossPercent: totalProfitLossPercent,
      },
    });
  } catch (error) {
    console.error("Portfolio performance error:", error);
    res.status(500).json({ error: "Failed to load portfolio performance" });
  }
});
app.get("/api/portfolio/breakdown", authenticateToken, (req: any, res) => {
  try {
    const manual = db.prepare("SELECT COALESCE(SUM(quantity * price), 0) as total FROM transactions WHERE userId = ? AND type = 'BUY' AND (source IS NULL OR source = 'MANUAL')").get(req.user.id) as any;
    const sip = db.prepare("SELECT COALESCE(SUM(amount), 0) as total FROM sip_executions WHERE userId = ? AND status = 'SUCCESS'").get(req.user.id) as any;
    res.json({ manualInvested: manual.total || 0, sipInvested: sip.total || 0 });
  } catch (error) {
    console.error("Portfolio breakdown error:", error);
    res.status(500).json({ error: "Failed to load investment breakdown" });
  }
});

app.post("/api/trade", authenticateToken, (req: any, res) => {
  const { symbol, quantity, price, type } = req.body;
  const userId = req.user.id;

  if (!symbol || typeof quantity !== "number" || quantity <= 0 || typeof price !== "number" || !["BUY", "SELL"].includes(type)) {
    return res.status(400).json({ error: "Invalid trade parameters" });
  }

  try {
    const user: any = db.prepare("SELECT balance FROM users WHERE id = ?").get(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    if (type === "BUY") {
      const totalCost = quantity * price;
      if (user.balance < totalCost) return res.status(400).json({ error: "Insufficient balance" });

      const tradeTx = db.transaction(() => {
        db.prepare("UPDATE users SET balance = balance - ? WHERE id = ?").run(totalCost, userId);

        const existing: any = db.prepare("SELECT * FROM portfolio WHERE userId = ? AND symbol = ?").get(userId, symbol);
        if (existing) {
          const newQty = existing.quantity + quantity;
          const newAvg = (existing.avgPrice * existing.quantity + price * quantity) / newQty;
          db.prepare("UPDATE portfolio SET quantity = ?, avgPrice = ? WHERE userId = ? AND symbol = ?").run(newQty, newAvg, userId, symbol);
        } else {
          db.prepare("INSERT INTO portfolio (userId, symbol, quantity, avgPrice) VALUES (?, ?, ?, ?)").run(userId, symbol, quantity, price);
        }

        db.prepare("INSERT INTO transactions (userId, symbol, quantity, price, type, source) VALUES (?, ?, ?, ?, 'BUY', 'MANUAL')")
          .run(userId, symbol, quantity, price);
      });
      tradeTx();
    } else {
      const existing: any = db.prepare("SELECT * FROM portfolio WHERE userId = ? AND symbol = ?").get(userId, symbol);
      if (!existing || existing.quantity < quantity) return res.status(400).json({ error: "Insufficient stock quantity" });

      const tradeTx = db.transaction(() => {
        const totalCredit = quantity * price;
        db.prepare("UPDATE users SET balance = balance + ? WHERE id = ?").run(totalCredit, userId);

        const newQty = existing.quantity - quantity;
        if (newQty === 0) {
          db.prepare("DELETE FROM portfolio WHERE userId = ? AND symbol = ?").run(userId, symbol);
        } else {
          db.prepare("UPDATE portfolio SET quantity = ? WHERE userId = ? AND symbol = ?").run(newQty, userId, symbol);
        }

        db.prepare("INSERT INTO transactions (userId, symbol, quantity, price, type, source) VALUES (?, ?, ?, ?, 'SELL', 'MANUAL')")
          .run(userId, symbol, quantity, price);
      });
      tradeTx();
    }

    res.json({ success: true });
  } catch (error) {
    console.error("Trade error:", error);
    res.status(500).json({ error: "Trade execution failed" });
  }
});

app.get("/api/transactions", authenticateToken, (req: any, res) => {
  const transactions = db.prepare("SELECT * FROM transactions WHERE userId = ? ORDER BY date DESC").all(req.user.id);
  res.json(transactions);
});

app.get("/api/sip/notifications", authenticateToken, (req: any, res) => {
  try {
    const afterId = Number(req.query.afterId || 0);
    const rows = db
      .prepare("SELECT * FROM sip_notifications WHERE userId = ? AND id > ? ORDER BY id ASC LIMIT 30")
      .all(req.user.id, Number.isFinite(afterId) ? afterId : 0);
    res.json(rows);
  } catch (error) {
    console.error("SIP notification fetch error:", error);
    res.status(500).json({ error: "Failed to load SIP notifications" });
  }
});

app.patch("/api/sip/notifications/read", authenticateToken, (req: any, res) => {
  try {
    db.prepare("UPDATE sip_notifications SET read = 1 WHERE userId = ?").run(req.user.id);
    res.json({ success: true });
  } catch (error) {
    console.error("SIP notifications read update error:", error);
    res.status(500).json({ error: "Failed to update SIP notifications" });
  }
});

app.get("/api/sip", authenticateToken, (req: any, res) => {
  try {
    const sips = db.prepare("SELECT * FROM sip_orders WHERE userId = ? ORDER BY createdAt DESC").all(req.user.id);
    res.json(sips);
  } catch (error) {
    console.error("SIP fetch error:", error);
    res.status(500).json({ error: "Failed to fetch SIP plans" });
  }
});

app.get("/api/sip/dashboard", authenticateToken, async (req: any, res) => {
  try {
    const sips: any[] = db.prepare("SELECT * FROM sip_orders WHERE userId = ? ORDER BY createdAt DESC").all(req.user.id) as any[];
    const activeSips = sips.filter((s) => s.status === "ACTIVE");

    let currentValue = 0;
    for (const sip of sips) {
      if (!sip.totalShares || sip.totalShares <= 0) continue;
      const price = await getCurrentStockPrice(sip.stockSymbol);
      currentValue += sip.totalShares * price;
    }

    const totalInvested = sips.reduce((acc, s) => acc + (s.totalInvested || 0), 0);
    const totalShares = sips.reduce((acc, s) => acc + (s.totalShares || 0), 0);

    res.json({
      sips,
      summary: {
        activeSips: activeSips.length,
        totalInvested,
        totalShares,
        profitLoss: currentValue - totalInvested,
      },
    });
  } catch (error) {
    console.error("SIP dashboard error:", error);
    res.status(500).json({ error: "Failed to load SIP dashboard" });
  }
});

app.get("/api/sip/:id", authenticateToken, (req: any, res) => {
  const sipId = Number(req.params.id);
  if (!Number.isFinite(sipId)) return res.status(400).json({ error: "Invalid SIP id" });

  try {
    const sip = db.prepare("SELECT * FROM sip_orders WHERE id = ? AND userId = ?").get(sipId, req.user.id);
    if (!sip) return res.status(404).json({ error: "SIP not found" });

    const history = db
      .prepare("SELECT * FROM sip_executions WHERE sipId = ? AND userId = ? ORDER BY executedAt DESC")
      .all(sipId, req.user.id);

    res.json({ sip, history });
  } catch (error) {
    console.error("SIP details error:", error);
    res.status(500).json({ error: "Failed to load SIP details" });
  }
});

app.post("/api/sip", authenticateToken, (req: any, res) => {
  const { stockSymbol, investmentAmount, frequency, startDate, endDate } = req.body;
  const symbol = String(stockSymbol || "").trim().toUpperCase();

  if (!symbol || !/^[A-Z.]{1,10}$/.test(symbol)) {
    return res.status(400).json({ error: "Invalid stock symbol" });
  }
  if (typeof investmentAmount !== "number" || investmentAmount <= 0) {
    return res.status(400).json({ error: "Investment amount must be greater than 0" });
  }
  if (!["WEEKLY", "MONTHLY"].includes(frequency)) {
    return res.status(400).json({ error: "Invalid SIP frequency" });
  }

  const parsedStart = parseISODate(startDate);
  if (!parsedStart) {
    return res.status(400).json({ error: "Invalid start date" });
  }

  let parsedEnd: Date | null = null;
  if (endDate) {
    parsedEnd = parseISODate(endDate);
    if (!parsedEnd) return res.status(400).json({ error: "Invalid end date" });
    if (parsedEnd < parsedStart) {
      return res.status(400).json({ error: "End date must be on or after start date" });
    }
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  let nextRunDate = new Date(parsedStart);
  while (nextRunDate < today) {
    nextRunDate = getNextSipDate(nextRunDate, frequency);
  }

  try {
    const result = db
      .prepare("INSERT INTO sip_orders (userId, stockSymbol, investmentAmount, frequency, startDate, endDate, nextRunDate) VALUES (?, ?, ?, ?, ?, ?, ?)")
      .run(
        req.user.id,
        symbol,
        investmentAmount,
        frequency,
        toISODate(parsedStart),
        parsedEnd ? toISODate(parsedEnd) : null,
        toISODate(nextRunDate)
      );

    const created = db.prepare("SELECT * FROM sip_orders WHERE id = ?").get(result.lastInsertRowid);
    res.status(201).json(created);
  } catch (error) {
    console.error("SIP create error:", error);
    res.status(500).json({ error: "Failed to create SIP" });
  }
});

app.put("/api/sip/:id", authenticateToken, (req: any, res) => {
  const sipId = Number(req.params.id);
  if (!Number.isFinite(sipId)) return res.status(400).json({ error: "Invalid SIP id" });

  try {
    const existing: any = db.prepare("SELECT * FROM sip_orders WHERE id = ? AND userId = ?").get(sipId, req.user.id);
    if (!existing) return res.status(404).json({ error: "SIP not found" });

    const symbol = req.body.stockSymbol ? String(req.body.stockSymbol).trim().toUpperCase() : existing.stockSymbol;
    const investmentAmount = typeof req.body.investmentAmount === "number" ? req.body.investmentAmount : existing.investmentAmount;
    const frequency = req.body.frequency || existing.frequency;
    const status = req.body.status || existing.status;

    if (!symbol || !/^[A-Z.]{1,10}$/.test(symbol)) return res.status(400).json({ error: "Invalid stock symbol" });
    if (typeof investmentAmount !== "number" || investmentAmount <= 0) return res.status(400).json({ error: "Invalid amount" });
    if (!["WEEKLY", "MONTHLY"].includes(frequency)) return res.status(400).json({ error: "Invalid frequency" });
    if (!["ACTIVE", "PAUSED", "CANCELLED", "COMPLETED"].includes(status)) return res.status(400).json({ error: "Invalid status" });

    const parsedStart = parseISODate(req.body.startDate || existing.startDate);
    const parsedEnd = (req.body.endDate ?? existing.endDate) ? parseISODate(req.body.endDate ?? existing.endDate) : null;
    if (!parsedStart) return res.status(400).json({ error: "Invalid start date" });
    if ((req.body.endDate ?? existing.endDate) && !parsedEnd) return res.status(400).json({ error: "Invalid end date" });
    if (parsedEnd && parsedEnd < parsedStart) return res.status(400).json({ error: "End date must be after start date" });

    let nextRunDate = existing.nextRunDate ? (parseISODate(existing.nextRunDate) || parsedStart) : parsedStart;
    if (req.body.startDate || req.body.frequency) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      nextRunDate = new Date(parsedStart);
      while (nextRunDate < today) {
        nextRunDate = getNextSipDate(nextRunDate, frequency);
      }
    }

    db.prepare("UPDATE sip_orders SET stockSymbol = ?, investmentAmount = ?, frequency = ?, startDate = ?, endDate = ?, status = ?, nextRunDate = ? WHERE id = ? AND userId = ?")
      .run(symbol, investmentAmount, frequency, toISODate(parsedStart), parsedEnd ? toISODate(parsedEnd) : null, status, toISODate(nextRunDate), sipId, req.user.id);

    const updated = db.prepare("SELECT * FROM sip_orders WHERE id = ?").get(sipId);
    res.json(updated);
  } catch (error) {
    console.error("SIP update error:", error);
    res.status(500).json({ error: "Failed to update SIP" });
  }
});

app.patch("/api/sip/:id/status", authenticateToken, (req: any, res) => {
  const sipId = Number(req.params.id);
  const { status } = req.body;

  if (!Number.isFinite(sipId)) return res.status(400).json({ error: "Invalid SIP id" });
  if (!["ACTIVE", "PAUSED", "CANCELLED"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  try {
    const existing: any = db.prepare("SELECT * FROM sip_orders WHERE id = ? AND userId = ?").get(sipId, req.user.id);
    if (!existing) return res.status(404).json({ error: "SIP not found" });

    db.prepare("UPDATE sip_orders SET status = ? WHERE id = ? AND userId = ?").run(status, sipId, req.user.id);
    const updated = db.prepare("SELECT * FROM sip_orders WHERE id = ?").get(sipId);
    res.json(updated);
  } catch (error) {
    console.error("SIP status update error:", error);
    res.status(500).json({ error: "Failed to update SIP status" });
  }
});

app.delete("/api/sip/:id", authenticateToken, (req: any, res) => {
  const sipId = Number(req.params.id);
  if (!Number.isFinite(sipId)) return res.status(400).json({ error: "Invalid SIP id" });

  try {
    const result = db.prepare("UPDATE sip_orders SET status = 'CANCELLED' WHERE id = ? AND userId = ?").run(sipId, req.user.id);
    if (result.changes === 0) return res.status(404).json({ error: "SIP not found" });
    createSipNotification(req.user.id, sipId, "COMPLETED", "SIP has been cancelled.");
    res.json({ success: true });
  } catch (error) {
    console.error("SIP cancel error:", error);
    res.status(500).json({ error: "Failed to cancel SIP" });
  }
});

app.get("/api/watchlist", authenticateToken, (req: any, res) => {
  const watchlist = db.prepare("SELECT symbol FROM watchlist WHERE userId = ?").all(req.user.id);
  res.json(watchlist);
});

app.post("/api/watchlist", authenticateToken, (req: any, res) => {
  const { symbol } = req.body;
  try {
    db.prepare("INSERT INTO watchlist (userId, symbol) VALUES (?, ?)").run(req.user.id, symbol);
    res.json({ success: true });
  } catch {
    res.status(400).json({ error: "Already in watchlist" });
  }
});

app.delete("/api/watchlist/:symbol", authenticateToken, (req: any, res) => {
  db.prepare("DELETE FROM watchlist WHERE userId = ? AND symbol = ?").run(req.user.id, req.params.symbol);
  res.json({ success: true });
});

app.get("/api/alerts", authenticateToken, (req: any, res) => {
  const alerts = db.prepare("SELECT * FROM alerts WHERE userId = ? AND active = 1").all(req.user.id);
  res.json(alerts);
});

app.post("/api/alerts", authenticateToken, (req: any, res) => {
  const { symbol, targetPrice, type } = req.body;
  db.prepare("INSERT INTO alerts (userId, symbol, targetPrice, type) VALUES (?, ?, ?, ?)").run(req.user.id, symbol, targetPrice, type);
  res.json({ success: true });
});

app.delete("/api/alerts/:id", authenticateToken, (req: any, res) => {
  db.prepare("DELETE FROM alerts WHERE userId = ? AND id = ?").run(req.user.id, req.params.id);
  res.json({ success: true });
});

app.post("/api/ai/chat", authenticateToken, async (req: any, res) => {
  const { message } = req.body;
  if (typeof message !== "string" || !message.trim()) {
    return res.status(400).json({ error: "Message is required" });
  }

  if (gemini) {
    try {
      const response = await gemini.models.generateContent({
        model: "gemini-2.0-flash",
        contents: message,
      });
      const text = response.text?.trim();
      if (text) {
        return res.json({ text });
      }
    } catch (error) {
      console.error("Gemini chat fallback error:", error);
    }
  }

  return res.json({ text: getLimitedChatReply(message) });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  await processDueSips();
  setInterval(() => {
    processDueSips();
  }, 60 * 1000);
}

startServer();


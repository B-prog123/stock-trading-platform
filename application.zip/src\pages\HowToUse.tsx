import React from 'react';
import { motion } from 'motion/react';
import {
  BookOpen,
  LayoutDashboard,
  LineChart,
  Newspaper,
  Briefcase,
  Bookmark,
  History,
  Wallet,
  Search,
  Bell,
  Brain,
  TrendingUp,
  TrendingDown,
  Activity,
  CandlestickChart,
  Info,
  MousePointer2,
  Clock3,
  BarChart3
} from 'lucide-react';

const appSections = [
  {
    title: 'Dashboard',
    icon: LayoutDashboard,
    description: 'Overview of your balance, portfolio performance, AI signals, and quick market snapshot.'
  },
  {
    title: 'Market',
    icon: LineChart,
    description: 'Search and analyze stocks, open interactive charts, and place buy/sell orders.'
  },
  {
    title: 'Market News',
    icon: Newspaper,
    description: 'Live headline feed with sentiment tags to quickly understand market direction.'
  },
  {
    title: 'Portfolio',
    icon: Briefcase,
    description: 'Detailed holdings, cost basis, gains/losses, and allocation tracking.'
  },
  {
    title: 'Watchlist',
    icon: Bookmark,
    description: 'Save symbols you want to monitor and revisit quickly.'
  },
  {
    title: 'Transactions',
    icon: History,
    description: 'Trade history log for executed buy/sell activity.'
  }
];

const iconGuide = [
  { icon: Search, label: 'Search', help: 'Find stocks by symbol or company name.' },
  { icon: Bookmark, label: 'Bookmark', help: 'Add or remove stock from watchlist.' },
  { icon: Bell, label: 'Bell', help: 'Open notifications for trade status and updates.' },
  { icon: Wallet, label: 'Wallet', help: 'Deposit virtual funds and manage buying power.' },
  { icon: Brain, label: 'AI', help: 'AI-generated recommendations and insights.' },
  { icon: TrendingUp, label: 'Bullish', help: 'Indicates upward momentum or positive sentiment.' },
  { icon: TrendingDown, label: 'Bearish', help: 'Indicates downward momentum or negative sentiment.' },
  { icon: Activity, label: 'Performance', help: 'Portfolio movement and analytics section.' },
  { icon: Clock3, label: 'Live/Time', help: 'Real-time or recently updated data.' }
];

export default function HowToUse() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-8 pb-10"
    >
      <section className="glass-card p-6 md:p-8 bg-gradient-to-r from-cyan-500/10 via-emerald-500/10 to-transparent border-cyan-500/20">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold flex items-center gap-3 text-[var(--text-primary)]">
              <BookOpen className="text-cyan-400" size={30} />
              Guide To Stockify AI
            </h2>
            <p className="mt-2 text-sm text-[var(--text-secondary)]">
              Complete guide to every section, key icon, and chart reading workflow.
            </p>
          </div>
        </div>
      </section>

      <section className="glass-card p-6 md:p-8">
        <h3 className="text-xl font-bold mb-5 flex items-center gap-2">
          <Info size={18} className="text-emerald-400" />
          Quick Start Flow
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            '1) Add funds from top bar',
            '2) Search stock in Market',
            '3) Analyze graph + intervals',
            '4) Execute buy/sell and track in Portfolio'
          ].map((item) => (
            <div key={item} className="rounded-2xl border border-[var(--border-color)] bg-[var(--bg-secondary)] p-4 text-sm text-[var(--text-secondary)]">
              {item}
            </div>
          ))}
        </div>
      </section>

      <section className="glass-card p-6 md:p-8">
        <h3 className="text-xl font-bold mb-5">Application Features</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {appSections.map((section) => {
            const Icon = section.icon;
            return (
              <div key={section.title} className="rounded-2xl border border-[var(--border-color)] bg-[var(--bg-secondary)] p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                    <Icon size={18} />
                  </div>
                  <h4 className="font-bold text-[var(--text-primary)]">{section.title}</h4>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">{section.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section className="glass-card p-6 md:p-8">
        <h3 className="text-xl font-bold mb-5">Icon Guide</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {iconGuide.map(({ icon: Icon, label, help }) => (
            <div key={label} className="rounded-2xl border border-[var(--border-color)] bg-[var(--bg-secondary)] p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon size={16} className="text-cyan-400" />
                <span className="font-semibold text-sm text-[var(--text-primary)]">{label}</span>
              </div>
              <p className="text-xs text-[var(--text-secondary)]">{help}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="glass-card p-6 md:p-8 border-emerald-500/20 bg-emerald-500/[0.02]">
        <h3 className="text-xl font-bold mb-5 flex items-center gap-2">
          <CandlestickChart size={20} className="text-emerald-400" />
          How To Read The Graph (Important)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="rounded-2xl border border-[var(--border-color)] bg-[var(--bg-secondary)] p-5">
            <h4 className="font-semibold mb-3 flex items-center gap-2 text-[var(--text-primary)]">
              <BarChart3 size={16} className="text-cyan-400" />
              Timeframe Buttons
            </h4>
            <ul className="text-sm text-[var(--text-secondary)] space-y-2">
              <li>`1D`: Intraday moves, best for short-term entries.</li>
              <li>`1W`: Weekly trend structure and momentum check.</li>
              <li>`1M`: Swing trend and pullback zones.</li>
              <li>`1Y` and `ALL`: Macro direction and long-term trend health.</li>
            </ul>
          </div>

          <div className="rounded-2xl border border-[var(--border-color)] bg-[var(--bg-secondary)] p-5">
            <h4 className="font-semibold mb-3 flex items-center gap-2 text-[var(--text-primary)]">
              <MousePointer2 size={16} className="text-cyan-400" />
              Practical Graph Reading
            </h4>
            <ul className="text-sm text-[var(--text-secondary)] space-y-2">
              <li>Identify trend first: higher highs/higher lows means bullish structure.</li>
              <li>Mark support and resistance where price repeatedly reacts.</li>
              <li>Use indicators (RSI/MACD/MA) as confirmation, not as standalone signals.</li>
              <li>Zoom out before trading to avoid reacting to noise.</li>
            </ul>
          </div>
        </div>

        <div className="mt-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4">
          <p className="text-sm text-[var(--text-secondary)]">
            Graph rule of thumb: decide direction on higher timeframe first (1M/1Y), then execute on lower timeframe (1D/1W). This reduces false entries.
          </p>
        </div>
      </section>
    </motion.div>
  );
}


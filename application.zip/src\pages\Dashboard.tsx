import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { StockRecommendation, PortfolioItem } from '../types';
import { TrendingUp, TrendingDown, Brain, ShieldAlert, Activity } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'motion/react';

import { getAIRecommendations } from '../services/aiService';
import MarketNews from '../components/MarketNews';

const mockChartData = [
  { name: 'Mon', value: 10000 },
  { name: 'Tue', value: 10200 },
  { name: 'Wed', value: 10100 },
  { name: 'Thu', value: 10500 },
  { name: 'Fri', value: 10800 },
  { name: 'Sat', value: 10700 },
  { name: 'Sun', value: 11200 },
];

export default function Dashboard() {
  const { token, user, setActiveTab, setSelectedSymbol, addNotification, logout } = useAuth();
  const [recommendations, setRecommendations] = useState<StockRecommendation[]>([]);
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isMounted, setIsMounted] = useState(false);

  const [timeframe, setTimeframe] = useState('1W');

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleTradeClick = (symbol: string) => {
    setSelectedSymbol(symbol);
    setActiveTab('market');
  };

  const getTimeframeData = (tf: string) => {
    const baseData = [
      { name: 'Mon', value: 10000 },
      { name: 'Tue', value: 10200 },
      { name: 'Wed', value: 10100 },
      { name: 'Thu', value: 10500 },
      { name: 'Fri', value: 10800 },
      { name: 'Sat', value: 10700 },
      { name: 'Sun', value: 11200 },
    ];

    switch (tf) {
      case '1D':
        return [
          { name: '09:00', value: 11000 },
          { name: '11:00', value: 11150 },
          { name: '13:00', value: 11080 },
          { name: '15:00', value: 11250 },
          { name: '17:00', value: 11200 },
        ];
      case '1M':
        return [
          { name: 'Week 1', value: 9500 },
          { name: 'Week 2', value: 10200 },
          { name: 'Week 3', value: 10800 },
          { name: 'Week 4', value: 11200 },
        ];
      case '1Y':
        return [
          { name: 'Jan', value: 8000 },
          { name: 'Mar', value: 8500 },
          { name: 'Jun', value: 9800 },
          { name: 'Sep', value: 10500 },
          { name: 'Dec', value: 11200 },
        ];
      case 'ALL':
        return [
          { name: '2022', value: 5000 },
          { name: '2023', value: 7500 },
          { name: '2024', value: 11200 },
        ];
      default:
        return baseData;
    }
  };

  const currentChartData = getTimeframeData(timeframe);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [recs, portRes] = await Promise.all([
          getAIRecommendations(),
          fetch('/api/portfolio', { headers: { Authorization: `Bearer ${token}` } })
        ]);
        
        if (portRes.status === 401 || portRes.status === 403) {
          logout();
          return;
        }

        setRecommendations(recs);
        if (portRes.ok) {
          const contentType = portRes.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            setPortfolio(await portRes.json());
          }
        }
      } catch (err) {
        console.error("Dashboard fetch error", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [token]);

  const totalInvested = portfolio.reduce((acc, item) => acc + (item.quantity * item.avgPrice), 0);
  const currentPortfolioValue = totalInvested * 1.05;
  const totalValue = (user?.balance || 0) + currentPortfolioValue;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-10 pb-10"
    >
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="text-4xl font-bold mb-2 text-gradient">Welcome, {user?.name}</h2>
          <p className="text-[var(--text-secondary)] font-medium">Your financial ecosystem is performing optimally today.</p>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-[var(--bg-secondary)] rounded-2xl border border-[var(--border-color)]">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] uppercase tracking-widest font-bold text-[var(--text-secondary)]">Market Live</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <StatCard 
            title="Total Portfolio Value" 
            value={`$${totalValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
            change="+5.2%"
            isPositive={true}
            icon={<Activity size={18} />}
          />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <StatCard 
            title="Invested Amount" 
            value={`$${totalInvested.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
            change="0.0%"
            isPositive={true}
            icon={<TrendingUp size={18} />}
          />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <StatCard 
            title="Available Balance" 
            value={`$${user?.balance.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
            change=""
            isPositive={true}
            icon={<ShieldAlert size={18} />}
          />
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }} 
          animate={{ opacity: 1, scale: 1 }} 
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 glass-card p-8 bg-gradient-to-br from-[var(--text-primary)]/[0.02] to-transparent"
        >
          <div className="flex items-center justify-between mb-10">
            <h3 className="text-xl font-bold flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                <Activity size={20} />
              </div>
              Performance Analytics
            </h3>
            <div className="flex gap-2 bg-[var(--bg-primary)] p-1 rounded-xl border border-[var(--border-color)]">
              {['1D', '1W', '1M', '1Y', 'ALL'].map(t => (
                <button 
                  key={t} 
                  onClick={() => setTimeframe(t)}
                  className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest uppercase transition-all ${timeframe === t ? 'bg-[var(--text-primary)] text-[var(--bg-primary)]' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="h-[350px] w-full min-w-0">
            {isMounted && (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={350} debounce={100}>
                <AreaChart data={currentChartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.05} vertical={false} />
                <XAxis dataKey="name" stroke="currentColor" opacity={0.2} fontSize={10} tickLine={false} axisLine={false} dy={10} />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: '16px', backdropFilter: 'blur(10px)', color: 'var(--text-primary)' }}
                  itemStyle={{ color: '#10b981' }}
                  cursor={{ stroke: 'var(--border-color)', strokeWidth: 2 }}
                />
                <Area type="monotone" dataKey="value" stroke="#10b981" strokeWidth={4} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
            )}
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }} 
          animate={{ opacity: 1, x: 0 }} 
          transition={{ delay: 0.5 }}
          className="space-y-8"
        >
          <div className="glass-card p-8 border-purple-500/10 bg-purple-500/[0.01]">
            <h3 className="text-xl font-bold mb-8 flex items-center gap-3">
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
                <Brain size={20} />
              </div>
              AI Alpha Signals
            </h3>
            <div className="space-y-5">
              {loading ? (
                [1, 2, 3, 4].map(i => <div key={i} className="h-24 bg-[var(--bg-secondary)] animate-pulse rounded-2xl" />)
              ) : (
                recommendations.map((rec) => (
                  <div 
                    key={rec.symbol} 
                    onClick={() => handleTradeClick(rec.symbol)}
                    className="p-5 rounded-2xl bg-[var(--bg-secondary)] border border-[var(--border-color)] hover:border-emerald-500/30 transition-all group cursor-pointer relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 blur-3xl -mr-12 -mt-12 group-hover:bg-emerald-500/10 transition-colors" />
                    <div className="flex justify-between items-start mb-3 relative z-10">
                      <div>
                        <span className="font-bold text-xl font-display tracking-tight text-[var(--text-primary)]">{rec.symbol}</span>
                        <p className="text-[10px] text-[var(--text-secondary)] uppercase tracking-widest font-bold">{rec.name}</p>
                      </div>
                      <div className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-[0.15em] ${
                        rec.trend === 'bullish' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                      }`}>
                        {rec.trend}
                      </div>
                    </div>
                    <p className="text-xs text-[var(--text-secondary)] line-clamp-2 mb-4 leading-relaxed relative z-10">{rec.reasoning}</p>
                    <div className="flex items-center justify-between relative z-10">
                      <div className="flex items-center gap-2 text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">
                        <ShieldAlert size={14} className={rec.riskScore > 7 ? 'text-red-400' : 'text-emerald-400'} />
                        Risk: <span className={rec.riskScore > 7 ? 'text-red-400' : 'text-emerald-400'}>{rec.riskScore}/10</span>
                      </div>
                      <button className="text-[10px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                        Trade <TrendingUp size={12} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>


        </motion.div>
      </div>
    </motion.div>
  );
}

function StatCard({ title, value, change, isPositive, icon }: any) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="glass-card p-8 relative overflow-hidden group h-full"
    >
      <div className="absolute top-0 right-0 p-6 text-[var(--text-primary)] opacity-5 group-hover:opacity-10 transition-opacity group-hover:scale-110 duration-500">
        {icon}
      </div>
      <p className="text-[var(--text-secondary)] text-[10px] uppercase tracking-[0.2em] font-bold mb-3">{title}</p>
      <div className="flex items-end gap-4">
        <h4 className="text-4xl font-bold font-display tracking-tighter text-[var(--text-primary)]">{value}</h4>
        {change && (
          <span className={`text-xs font-bold mb-2 flex items-center gap-1 px-2 py-1 rounded-lg ${isPositive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
            {isPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {change}
          </span>
        )}
      </div>
    </motion.div>
  );
}



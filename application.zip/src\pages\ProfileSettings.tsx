import React, { useEffect, useState } from 'react';
import { useAuth } from '../App';
import { Save, User as UserIcon } from 'lucide-react';

export default function ProfileSettings() {
  const { token, user, refreshUser, addNotification, logout } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setName(user?.name || '');
  }, [user?.name]);

  const saveProfile = async () => {
    const trimmed = name.trim();
    if (!trimmed) {
      addNotification('Validation Error', 'Name cannot be empty.', 'warning');
      return;
    }

    setIsSaving(true);
    try {
      const res = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ name: trimmed }),
      });

      if (res.status === 401 || res.status === 403) {
        logout();
        return;
      }

      if (!res.ok) {
        const data = await res.json().catch(() => ({ error: 'Failed to update profile' }));
        addNotification('Update Failed', data.error || 'Could not save profile.', 'error');
        return;
      }

      await refreshUser();
      addNotification('Profile Updated', 'Your profile settings were saved.', 'success');
    } catch (error) {
      console.error('Profile update error:', error);
      addNotification('Network Error', 'Unable to save profile right now.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-2xl">
      <div className="mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-[var(--text-primary)]">Profile Settings</h2>
        <p className="text-sm text-[var(--text-secondary)] mt-1">Manage your public account details.</p>
      </div>

      <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-3xl p-6 md:p-8 space-y-6">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-400 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
          <UserIcon size={24} />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] text-[var(--text-secondary)] uppercase tracking-[0.2em] font-bold ml-1">Display Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-2xl py-3 px-4 text-sm text-[var(--text-primary)] focus:outline-none focus:border-emerald-500/50 transition-all"
            placeholder="Enter your name"
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] text-[var(--text-secondary)] uppercase tracking-[0.2em] font-bold ml-1">Email</label>
          <input
            type="email"
            value={user?.email || ''}
            disabled
            className="w-full bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-2xl py-3 px-4 text-sm text-[var(--text-secondary)] cursor-not-allowed"
          />
          <p className="text-xs text-[var(--text-secondary)]">Email changes are disabled for now.</p>
        </div>

        <button
          onClick={saveProfile}
          disabled={isSaving}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-emerald-500 text-white font-bold text-sm hover:bg-emerald-600 transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          <Save size={16} />
          {isSaving ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </div>
  );
}
